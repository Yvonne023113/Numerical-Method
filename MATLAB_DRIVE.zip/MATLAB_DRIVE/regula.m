% Define the function
f = @(x) x.^3 - x - 2;

% Initial interval
a = 1;
b = 2;

% Check initial condition
if f(a)*f(b) > 0
    error('Function does not change sign on the interval. Choose a different interval.')
end

tol = 1e-6;      % Tolerance
max_iter = 100;  % Maximum iterations
iter = 0;

% Initialize
fa = f(a);
fb = f(b);
c = a; % Initial c value

while iter < max_iter
    % Calculate c using false position formula
    c_old = c;
    c = b - fb*(b - a)/(fb - fa);
    fc = f(c);
    
    % Check for convergence
    if abs(fc) < tol || abs(c - c_old) < tol
        break
    end
    
    % Update interval
    if fa*fc < 0
        b = c;
        fb = fc;
    else
        a = c;
        fa = fc;
    end
    
    iter = iter + 1;
end

fprintf('Root found at x = %.6f after %d iterations\n', c, iter)

% Plot the function and root
x = linspace(0, 3, 400);
y = f(x);

plot(x, y, 'b-', 'LineWidth', 2)
hold on
plot(c, f(c), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r')
plot(x, zeros(size(x)), 'k--') % x-axis

xlabel('x')
ylabel('f(x)')
title('Regula-Falsi (False Position) Method')
legend('f(x)', 'Root', 'x-axis')

grid on
hold off
