% Define the function
f = @(x) x.^3 - x - 2;

% Interval [a, b]
a = 1;
b = 2;

% Check that the root is bracketed
if f(a)*f(b) > 0
    error('Function does not change sign on the interval. Choose a different interval.')
end

tol = 1e-6;      % Tolerance for stopping
max_iter = 100;  % Maximum number of iterations
iter = 0;

% Bisection algorithm
while (b - a)/2 > tol && iter < max_iter
    c = (a + b)/2;
    fc = f(c);
    
    if fc == 0
        break  % Found exact root
    elseif f(a)*fc < 0
        b = c;
    else
        a = c;
    end
    
    iter = iter + 1;
end

root = (a + b)/2;
fprintf('Root found at x = %.6f after %d iterations\n', root, iter)

% Plot the function and root
x = linspace(0, 3, 400);
y = f(x);

plot(x, y, 'b-', 'LineWidth', 2)
hold on
plot(root, f(root), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r')
plot(x, zeros(size(x)), 'k--') % x-axis

xlabel('x')
ylabel('f(x)')
title('Bisection Method Root Finding')
legend('f(x)', 'Root', 'x-axis')

grid on
hold off
