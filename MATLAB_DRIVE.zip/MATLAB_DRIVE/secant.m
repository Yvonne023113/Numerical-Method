% Define the function
f = @(x) x.^3 - x - 2;

% Initial guesses
x0 = 1;
x1 = 2;

tol = 1e-6;      % Tolerance
max_iter = 50;   % Maximum iterations
iter = 0;

while iter < max_iter
    f_x0 = f(x0);
    f_x1 = f(x1);
    
    if (f_x1 - f_x0) == 0
        error('Division by zero in secant method')
    end
    
    % Secant formula
    x2 = x1 - f_x1*(x1 - x0)/(f_x1 - f_x0);
    
    if abs(x2 - x1) < tol
        break
    end
    
    % Update points
    x0 = x1;
    x1 = x2;
    iter = iter + 1;
end

fprintf('Root found at x = %.6f after %d iterations\n', x2, iter)

% Plot function and root
x = linspace(0, 3, 400);
y = f(x);

plot(x, y, 'b-', 'LineWidth', 2)
hold on
plot(x2, f(x2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r')
plot(x, zeros(size(x)), 'k--') % x-axis

xlabel('x')
ylabel('f(x)')
title('Secant Method')
legend('f(x)', 'Root', 'x-axis')

grid on
hold off
