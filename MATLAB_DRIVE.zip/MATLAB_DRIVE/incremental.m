% Define the function
f = @(x) x.^3 - x - 2;

% Search interval and increment
a = 0;
b = 3;
delta = 0.1;

x_vals = a:delta:b;
f_vals = f(x_vals);

fprintf('Intervals where sign changes (possible roots):\n')

for i = 1:length(x_vals)-1
    if f_vals(i)*f_vals(i+1) < 0
        fprintf('Root between x = %.2f and x = %.2f\n', x_vals(i), x_vals(i+1))
    elseif f_vals(i) == 0
        fprintf('Exact root at x = %.2f\n', x_vals(i))
    end
end

% Plot function and points of sign change
plot(x_vals, f_vals, 'b-', 'LineWidth', 2)
hold on
plot(x_vals, zeros(size(x_vals)), 'k--') % x-axis

% Mark intervals with sign change
for i = 1:length(x_vals)-1
    if f_vals(i)*f_vals(i+1) < 0
        plot([x_vals(i) x_vals(i+1)], [f_vals(i) f_vals(i+1)], 'ro-', 'MarkerFaceColor', 'r')
    elseif f_vals(i) == 0
        plot(x_vals(i), 0, 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g')
    end
end

xlabel('x')
ylabel('f(x)')
title('Incremental Search Method')
legend('f(x)', 'x-axis', 'Sign change intervals', 'Location', 'best')

grid on
hold off
