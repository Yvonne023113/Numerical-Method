% Define the function and its derivative
f = @(x) x.^3 - x - 2;
df = @(x) 3*x.^2 - 1;

% Initial guess
x0 = 1.5;

tol = 1e-6;      % Tolerance
max_iter = 50;   % Max iterations
iter = 0;
x = x0;

while iter < max_iter
    fx = f(x);
    dfx = df(x);
    
    if dfx == 0
        error('Derivative zero. No solution found.')
    end
    
    x_new = x - fx/dfx;
    
    if abs(x_new - x) < tol
        break
    end
    
    x = x_new;
    iter = iter + 1;
end

fprintf('Root found at x = %.6f after %d iterations\n', x, iter)

% Plot the function and root
X = linspace(0, 3, 400);
Y = f(X);

plot(X, Y, 'b-', 'LineWidth', 2)
hold on
plot(x, f(x), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r')
plot(X, zeros(size(X)), 'k--') % x-axis

xlabel('x')
ylabel('f(x)')
title('Newton-Raphson Method')
legend('f(x)', 'Root', 'x-axis')

grid on
hold off
