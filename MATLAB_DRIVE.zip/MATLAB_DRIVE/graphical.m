% Define the range for x
x = -5:0.1:5;

% Equations
y1 = 8 - 2*x;
y2 = x - 2;

% Plot both lines
plot(x, y1, 'r', 'LineWidth', 2)
hold on
plot(x, y2, 'b', 'LineWidth', 2)

% Add labels and legend
xlabel('x')
ylabel('y')
title('Graphical Solution of Linear Equations')
legend('2x + y = 8', 'x - y = 2')

% Find intersection point (solution)
A = [2 1; 1 -1];
b = [8; 2];
solution = A\b;

% Plot solution point
plot(solution(1), solution(2), 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'k')

text(solution(1)+0.2, solution(2), sprintf('(%.2f, %.2f)', solution(1), solution(2)))

grid on
hold off

x = -1:0.01:5;
f = x.^3 - 6*x.^2 + 9*x - 4;

plot(x, f, 'LineWidth', 2)
hold on
plot(x, zeros(size(x)), 'k--') % x-axis

xlabel('x')
ylabel('f(x)')
title('Graphical Root Finding')
grid on

% Approximate roots by visually inspecting plot, or use 'fzero'
root1 = fzero(@(x) x^3 - 6*x^2 + 9*x - 4, 0);
root2 = fzero(@(x) x^3 - 6*x^2 + 9*x - 4, 3);

plot(root1, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r')
plot(root2, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r')

legend('f(x)', 'x-axis', 'Roots')
hold off
x = 0:0.01:2*pi;
y1 = sin(x);
y2 = cos(x);

plot(x, y1, 'b', 'LineWidth', 2)
hold on
plot(x, y2, 'r', 'LineWidth', 2)
xlabel('x')
ylabel('y')
title('Intersection of sin(x) and cos(x)')
legend('sin(x)', 'cos(x)')

% Find approximate intersections numerically
diff = y1 - y2;
signChange = diff(1:end-1).*diff(2:end) < 0;
x_intersections = [];

for i = find(signChange)
    x_inter = fzero(@(t) sin(t) - cos(t), [x(i), x(i+1)]);
    x_intersections = [x_intersections x_inter];
end

y_intersections = sin(x_intersections);
plot(x_intersections, y_intersections, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k')

hold off